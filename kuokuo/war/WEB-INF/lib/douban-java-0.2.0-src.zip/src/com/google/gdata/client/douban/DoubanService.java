package com.google.gdata.client.douban;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import net.oauth.OAuth;
import net.oauth.OAuthAccessor;
import net.oauth.OAuthConsumer;
import net.oauth.OAuthMessage;
import net.oauth.OAuthServiceProvider;
import net.oauth.client.HttpClientPool;
import net.oauth.client.OAuthClient;
import net.oauth.client.OAuthHttpClient;

import org.apache.commons.httpclient.HttpClient;

import com.google.gdata.client.Query;
import com.google.gdata.client.Service;
import com.google.gdata.client.Query.CustomParameter;
import com.google.gdata.client.http.GoogleGDataRequest;
import com.google.gdata.data.BaseEntry;
import com.google.gdata.data.ExtensionProfile;
import com.google.gdata.data.TextConstruct;
import com.google.gdata.data.douban.Attribute;
import com.google.gdata.data.douban.CollectionEntry;
import com.google.gdata.data.douban.CollectionFeed;
import com.google.gdata.data.douban.MiniblogEntry;
import com.google.gdata.data.douban.MiniblogFeed;
import com.google.gdata.data.douban.Namespaces;
import com.google.gdata.data.douban.NoteEntry;
import com.google.gdata.data.douban.NoteFeed;
import com.google.gdata.data.douban.ReviewEntry;
import com.google.gdata.data.douban.ReviewFeed;
import com.google.gdata.data.douban.Status;
import com.google.gdata.data.douban.Subject;
import com.google.gdata.data.douban.SubjectEntry;
import com.google.gdata.data.douban.SubjectFeed;
import com.google.gdata.data.douban.Tag;
import com.google.gdata.data.douban.TagEntry;
import com.google.gdata.data.douban.TagFeed;
import com.google.gdata.data.douban.UserEntry;
import com.google.gdata.data.douban.UserFeed;
import com.google.gdata.data.extensions.Rating;
import com.google.gdata.util.ContentType;
import com.google.gdata.util.ServiceException;

public class DoubanService extends Service {

	protected String apiKey;
	protected String apiParam;
	protected String secret;

	public static OAuthClient CLIENT = new OAuthHttpClient(
			new HttpClientPool() {
				// This trivial 'pool' simply allocates a new client every time.
				// More efficient implementations are possible.
				public HttpClient getHttpClient(URL server) {
					return new HttpClient();
				}
			});
	protected OAuthAccessor accessor;
	protected OAuthAccessor requestAccessor;
	protected List<Map.Entry<String, String>> parameters;
	protected OAuthConsumer client;

	static String requestTokenURL = "http://www.douban.com/service/auth/request_token";
	static String userAuthorizationURL = "http://www.douban.com/service/auth/authorize";
	static String accessTokenURL = "http://www.douban.com/service/auth/access_token";

	/**
	 * Constructs a DoubanService instance connecting to the Douban service for
	 * an application with the name {@code applicationName}.
	 * 
	 * @param applicationName
	 *            the name of the client application accessing the service.
	 *            Application names should preferably have the format
	 *            [company-id]-[app-name]-[app-version].
	 * @param apiKey
	 *            the douban api key
	 */
	public DoubanService(String applicationName, String apiKey) {
		ExtensionProfile profile = getExtensionProfile();
		this.apiKey = apiKey;
		this.apiParam = "apikey=" + apiKey;

		profile.addDeclarations(new UserEntry());
		profile.addDeclarations(new SubjectEntry());
		profile.addDeclarations(new ReviewEntry());
		profile.addDeclarations(new CollectionEntry());
		profile.addDeclarations(new TagEntry());
		profile.addDeclarations(new NoteEntry());
		profile.addDeclarations(new MiniblogEntry());
		
		requestFactory = new GoogleGDataRequest.Factory();
		this.accessor = null;

		if (applicationName != null) {
			requestFactory.setHeader("User-Agent", applicationName + " "
					+ getServiceVersion());
		} else {
			requestFactory.setHeader("User-Agent", getServiceVersion());
		}
	}

	public DoubanService(String applicationName, String apiKey, String secret) {
		this(applicationName, apiKey);

		this.apiKey = apiKey;
		this.secret = secret;
		OAuthServiceProvider provider = new OAuthServiceProvider(
				requestTokenURL, userAuthorizationURL, accessTokenURL);

		this.client = new OAuthConsumer(null, apiKey, secret, provider);
		this.accessor = new OAuthAccessor(this.client);

		this.requestAccessor = new OAuthAccessor(this.client);
		
		this.client.setProperty("oauth_signature_method", OAuth.HMAC_SHA1);
	}

	public String getAuthorizationUrl(String callback) {
		String authorization_url = null;
		try {
			CLIENT.getRequestToken(this.requestAccessor);

			authorization_url = accessor.consumer.serviceProvider.userAuthorizationURL
					+ "?" + "oauth_token=" + this.requestAccessor.requestToken;
			if (callback != null)
				authorization_url += "&oauth_callback=" + callback;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return authorization_url;
	}

	public ArrayList<String> setAccessToken(String oauth_token, String oauth_token_secret) {
		this.accessor.accessToken = oauth_token;
		this.accessor.tokenSecret = oauth_token_secret;
		ArrayList<String> tokens = new ArrayList<String>(2);
		tokens.add(this.accessor.accessToken);
		tokens.add(this.accessor.tokenSecret);
		return tokens;

		/*
		OAuthMessage result;
		try {
					
			result = CLIENT.invoke(accessor, "http://api.douban.com/test?a=b&c=d", null);
			String responseBody = result.getBodyAsString();
			System.out.println(responseBody);
			
			try {
		    OAuthMessage oauth_req = accessor.newRequestMessage(null, "http://api.douban.com/people/@me", null);
			//System.out.println(oauth_req);
			String url = OAuth.addParameters(oauth_req.URL, oauth_req.getParameters());
			
			//System.out.println(url);
			result = CLIENT.invoke(accessor, "http://api.douban.com/people/%40me", null);
			responseBody = result.getBodyAsString();
			System.out.println(responseBody);
			
			} catch(OAuthProblemException e){
				System.out.println(e.getHttpStatusCode());
			}
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		*/
	}
	
	public void getAccessToken() {
		OAuthMessage result;
		try {
			result = CLIENT.invoke(this.requestAccessor,
					accessor.consumer.serviceProvider.accessTokenURL, OAuth
							.newList("oauth_token",
									this.requestAccessor.requestToken));

			Map<String, String> responseParameters = OAuth.newMap(result
					.getParameters());

			this.accessor.accessToken = responseParameters.get("oauth_token");
			this.accessor.tokenSecret = responseParameters
					.get("oauth_token_secret");
			//System.out.println(this.accessor.accessToken);
			//System.out.println(this.accessor.tokenSecret);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static final String toString(Object from) {
		return (from == null) ? null : from.toString();
	}

	@SuppressWarnings("unchecked")
	public GDataRequest createFeedRequest(Query query) throws IOException,
			ServiceException {
		GDataRequest request = null;
		OAuthMessage oauthRequest = null;
	    setTimeouts(request);
	    
		if(this.accessor == null){
			//query.setApiKey(this.apiKey);
			List<CustomParameter> customParams = query.getCustomParameters();
			customParams.add(new CustomParameter("apikey", this.apiKey));
			request =super.requestFactory.getRequest(query, super.getContentType());
			return request;
		}
		
		request =super.requestFactory.getRequest(query, super.getContentType());
	    try {
			Collection<Map.Entry<String, String>> p = new ArrayList<Map.Entry<String, String>>();

			p.add(new OAuth.Parameter("oauth_version", "1.0"));
			String methodType = "GET";
			GDataRequest.RequestType type= GDataRequest.RequestType.QUERY;
			
			switch (type) {

			case INSERT:
				methodType = "POST";
				break;
			case UPDATE:
				methodType = "PUT";
				break;

			case DELETE:
				methodType = "DELETE";
				break;
			
			}
			oauthRequest = this.accessor.newRequestMessage(methodType,
					query.getUrl().toString() , p);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		parameters = oauthRequest.getParameters();

		String url = "OAuth realm=\"\"";

		for (Map.Entry parameter : parameters) {
			url += ", ";
			url += OAuth.percentEncode(toString(parameter.getKey()));
			url += "=\"";
			url += OAuth.percentEncode(toString(parameter.getValue()));
			url += "\"";
		}

		request.setHeader("Authorization", url);
		//System.out.println("Authorization@createFeedRequest : " + url);
		return request;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public GDataRequest createRequest(GDataRequest.RequestType type,
			URL requestUrl, ContentType contentType) throws IOException,
			ServiceException {
		//System.out.println("in createRequest");
		GDataRequest request = null;
		OAuthMessage oauthRequest = null;
		
		if(this.accessor == null){
			String url = requestUrl.toString();
			if(url.indexOf('?')==-1){
				url = url + "?" + this.apiParam;
			} else {
				url = url + "&" + this.apiParam;
			}
			request = super.createRequest(type, new URL(url),
					contentType);
			return request;
		}
		
		
		request = super.createRequest(type, requestUrl,
				contentType);
		try {
			Collection<Map.Entry<String, String>> p = new ArrayList<Map.Entry<String, String>>();

			p.add(new OAuth.Parameter("oauth_version", "1.0"));
			String methodType = "GET";
			
			switch (type) {

			case INSERT:
				methodType = "POST";
				break;
			case UPDATE:
				methodType = "PUT";
				break;

			case DELETE:
				methodType = "DELETE";
				break;
			}
			oauthRequest = this.accessor.newRequestMessage(methodType,
					requestUrl.toString(), p);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		parameters = oauthRequest.getParameters();

		String url = "OAuth realm=\"\"";

		for (Map.Entry parameter : parameters) {
			url += ", ";
			url += OAuth.percentEncode(toString(parameter.getKey()));
			url += "=\"";
			url += OAuth.percentEncode(toString(parameter.getValue()));
			url += "\"";
		}

		request.setHeader("Authorization", url);
		//System.out.println("Authorization : " + url);
		return request;
	}

	
	public <E extends BaseEntry<?>> E getEntry(String entryUrl,
			Class<E> entryClass) throws IOException, ServiceException {
		return super.getEntry(new URL(entryUrl), entryClass);
	}


	/**
	 * Get douban user info.
	 * 
	 * @param userId
	 *            the user Id string
	 */
	public UserEntry getUser(String userId) throws IOException,
			ServiceException {
		String url = Namespaces.userURL + "/" + userId;
		return getEntry(url, UserEntry.class);
	}
	public UserEntry getAuthorizedUser() throws IOException,
			ServiceException {
		String url = Namespaces.userURL + "/%40me";
		return getEntry(url, UserEntry.class);
	}
	
	/**
	 * Find user info.
	 * 
	 * @param q
	 *            the query keyword
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public UserFeed findUser(String q, int startIndex, int maxResult)
			throws IOException, ServiceException {
		DoubanQuery query = new DoubanQuery(new URL(Namespaces.userURLSlash));
		query.setFullTextQuery(q);
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, UserFeed.class);
	}
	
	public UserFeed getUserFriends(String userId,int startIndex, int maxResult) throws IOException,
			ServiceException {
		String url = Namespaces.userURL + "/" + userId + "/friends";
		DoubanQuery query = new DoubanQuery(new URL(url));
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);
		return getFeed(query, UserFeed.class);
	}
	

	public SubjectEntry getBook(String bookId) throws IOException,
			ServiceException {
		String url = bookId;
		if (url.lastIndexOf("http") != 0) {
			url = Namespaces.bookSubjectURL + "/" + bookId;
		}
		return getEntry(url, SubjectEntry.class);
	}

	public SubjectEntry getBook(int bookId) throws IOException,
			ServiceException {
		String url = Namespaces.bookSubjectURL + "/" + bookId;
		return getEntry(url, SubjectEntry.class);
	}

	public SubjectEntry getMusic(String musicId) throws IOException,
			ServiceException {
		String url = musicId;
		if (url.lastIndexOf("http") != 0) {
			url = Namespaces.musicSubjectURL + "/" + musicId;
		}
		return getEntry(url, SubjectEntry.class);
	}

	public SubjectEntry getMusic(int musicId) throws IOException,
			ServiceException {
		String url = Namespaces.musicSubjectURL + "/" + musicId;
		return getEntry(url, SubjectEntry.class);
	}

	public SubjectEntry getMovie(String movieId) throws IOException,
			ServiceException {
		String url = movieId;
		if (url.lastIndexOf("http") != 0) {
			url = Namespaces.movieSubjectURL + "/" + movieId;
		}
		return getEntry(url, SubjectEntry.class);
	}

	public SubjectEntry getMovie(int movieId) throws IOException,
			ServiceException {
		String url = Namespaces.movieSubjectURL + "/" + movieId;
		return getEntry(url, SubjectEntry.class);
	}

	public NoteEntry getNote(String noteId) throws IOException, ServiceException {
		String url = Namespaces.noteURL + "/" + noteId;
		return getEntry(url, NoteEntry.class);
	}
	public NoteFeed getUserNotes(String userId, int startIndex, int maxResult) throws IOException, ServiceException {
		String url = Namespaces.userURL + "/" + userId + "/notes";
		DoubanQuery query = new DoubanQuery(new URL(url));
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, NoteFeed.class);
	}
	
	public NoteEntry createNote(
			TextConstruct title, TextConstruct content, String privacy, String can_reply)
			throws IOException, ServiceException {
		String url = Namespaces.noteCreateURL;
		NoteEntry ne = new NoteEntry();
		
		if (title != null) {
			ne.setTitle(title);
		}
		if (content != null) {
			ne.setContent(content);
		}
		ArrayList<Attribute> atts = new ArrayList<Attribute>(2);
		Attribute a1 = new Attribute();
		a1.setName("privacy");
		a1.setContent(privacy);
		Attribute a2 = new Attribute();
		a2.setName("can_reply");
		a2.setContent(can_reply);
		atts.add(a1);
		atts.add(a2);
		ne.setAttributes(atts);		

		return insert(new URL(url), ne);
	}
	
	public NoteEntry updateNote(NoteEntry ne, TextConstruct title, TextConstruct content, String privacy, String can_reply) throws MalformedURLException,
			IOException, ServiceException {

		if (title != null) {
			ne.setTitle(title);
		}
		if (content != null) {
			ne.setContent(content);
		}
		ArrayList<Attribute> atts = new ArrayList<Attribute>(2);
		Attribute a1 = new Attribute();
		a1.setName("privacy");
		a1.setContent(privacy);
		Attribute a2 = new Attribute();
		a2.setName("can_reply");
		a2.setContent(can_reply);
		atts.add(a1);
		atts.add(a2);
		ne.setAttributes(atts);	
		 
		return update(new URL(ne.getId()), ne);
	}
	
	public void deleteNote(NoteEntry ne) throws MalformedURLException,
			IOException, ServiceException {
		delete(new URL(ne.getId()));
	}
	
	public MiniblogFeed getUserMiniblogs(String userId, int startIndex, int maxResult) throws IOException, ServiceException {
		String url = Namespaces.userURL + "/" + userId + "/miniblog";
		DoubanQuery query = new DoubanQuery(new URL(url));
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, MiniblogFeed.class);
	}
	
	public MiniblogFeed getContactsMiniblogs(String userId, int startIndex, int maxResult) throws IOException, ServiceException {
		String url = Namespaces.userURL + "/" + userId + "/miniblog/contacts";
		DoubanQuery query = new DoubanQuery(new URL(url));
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, MiniblogFeed.class);
	}
	
	public MiniblogEntry createSaying(
			TextConstruct content)
			throws IOException, ServiceException {
		String url = Namespaces.sayingCreateURL;
		MiniblogEntry me = new MiniblogEntry();
		
		if (content != null) {
			me.setContent(content);
		}
		 
		return insert(new URL(url), me);
	}
	
	public void deleteMiniblog(MiniblogEntry me) throws MalformedURLException,
			IOException, ServiceException {
		delete(new URL(me.getId()));
	}
	

	/**
	 * Find book info.
	 * 
	 * @param q
	 *            the query keyword
	 * @param tag
	 *            the tag string
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public SubjectFeed findBook(String q, String tag, int startIndex,
			int maxResult) throws IOException, ServiceException {
		SubjectQuery query = new SubjectQuery(new URL(
				Namespaces.bookSubjectsURL));
		query.setFullTextQuery(q);
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);
		query.setTag(tag);

		return query(query, SubjectFeed.class);
	}

	/**
	 * Find movie info.
	 * 
	 * @param q
	 *            the query keyword
	 * @param tag
	 *            the tag string
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public SubjectFeed findMovie(String q, String tag, int startIndex,
			int maxResult) throws IOException, ServiceException {
		SubjectQuery query = new SubjectQuery(new URL(
				Namespaces.movieSubjectsURL));
		query.setFullTextQuery(q);
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);
		query.setTag(tag);

		return query(query, SubjectFeed.class);
	}

	/**
	 * Find music info.
	 * 
	 * @param q
	 *            the query keyword
	 * @param tag
	 *            the tag string
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public SubjectFeed findMusic(String q, String tag, int startIndex,
			int maxResult) throws IOException, ServiceException {
		SubjectQuery query = new SubjectQuery(new URL(
				Namespaces.musicSubjectsURL));
		query.setFullTextQuery(q);
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);
		query.setTag(tag);

		return query(query, SubjectFeed.class);
	}

	/**
	 * @deprecated you can contact douban if you want to use this api
	 * Get related book info
	 * 
	 * @param bookId
	 *            the Id string of the book
	 * 
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public SubjectFeed getBookRelated(String bookId, int startIndex,
			int maxResult) throws IOException, ServiceException {
		SubjectQuery query = new SubjectQuery(new URL(Namespaces.bookSubjectURL
				+ "/" + bookId + "/related"));

		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, SubjectFeed.class);

	}

	/**
	 * @deprecated you can contact douban if you want to use this api
	 * Get related movie info
	 * 
	 * @param bookId
	 *            the Id string of the movie
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public SubjectFeed getMovieRelated(String movieId, int startIndex,
			int maxResult) throws IOException, ServiceException {
		SubjectQuery query = new SubjectQuery(new URL(
				Namespaces.movieSubjectURL + "/" + movieId + "/related"));
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, SubjectFeed.class);

	}

	/**
	 *  @deprecated you can contact douban if you want to use this api
	 * Get related music info
	 * 
	 * @param musicId
	 *            the Id string of the music
	 * 
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public SubjectFeed getMusicRelated(String musicId, int startIndex,
			int maxResult) throws IOException, ServiceException {
		SubjectQuery query = new SubjectQuery(new URL(
				Namespaces.musicSubjectURL + "/" + musicId + "/related"));

		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, SubjectFeed.class);

	}

	/**
	 * Get review info
	 * 
	 * @param reviewId
	 *            the review string Id of the review
	 * 
	 */
	public ReviewEntry getReview(String reviewId) throws IOException,
			ServiceException {
		String url = Namespaces.reviewURL + "/" + reviewId;
		return getEntry(url, ReviewEntry.class);
	}

	/**
	 * Get user's review info
	 * 
	 * @param userId
	 *            the user Id
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public ReviewFeed getUserReviews(String userId) throws IOException,
			ServiceException {
		String url = Namespaces.userURL + "/" + userId + "/reviews";
		DoubanQuery query = new DoubanQuery(new URL(url));

		return getFeed(query, ReviewFeed.class);
	}

	/**
	 * Get book's review info
	 * 
	 * @param bookId
	 *            the book Id
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public ReviewFeed getBookReviews(String bookId, int startIndex,
			int maxResult, String orderby) throws IOException, ServiceException {
		ReviewQuery query = new ReviewQuery(new URL(Namespaces.bookSubjectURL
				+ "/" + bookId + "/reviews"));
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);
		query.setOrderby(orderby);

		return query(query, ReviewFeed.class);
	}

	/**
	 * Get movie's review info
	 * 
	 * @param movieId
	 *            the movie Id
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public ReviewFeed getMovieReviews(String movieId, int startIndex,
			int maxResult, String orderby) throws IOException, ServiceException {
		ReviewQuery query = new ReviewQuery(new URL(Namespaces.movieSubjectURL
				+ "/" + movieId + "/reviews"));
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);
		query.setOrderby(orderby);
		return query(query, ReviewFeed.class);
	}

	/**
	 * Get music's review info
	 * 
	 * @param movieId
	 *            the movie Id
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public ReviewFeed getMusicReviews(String musicId, int startIndex,
			int maxResult, String orderby) throws IOException, ServiceException {
		ReviewQuery query = new ReviewQuery(new URL(Namespaces.musicSubjectURL
				+ "/" + musicId + "/reviews"));
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);
		query.setOrderby(orderby);
		return query(query, ReviewFeed.class);
	}

	/**
	 * Get user's collection info
	 * 
	 * @param userId
	 *            the user Id
	 * @param cat
	 *            the cat info(one of the "movie","music" and "book")
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public CollectionFeed getUserCollections(String userId, String cat,
			String tag, String status, int startIndex, int maxResult)
			throws IOException, ServiceException {

		CollectionQuery query = new CollectionQuery(new URL(Namespaces.userURL
				+ "/" + userId + "/collection"));
		query.setCat(cat);
		query.setTag(tag);
		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, CollectionFeed.class);
	}

	public CollectionEntry getCollection(String cid)
			throws IOException, ServiceException {

		String url = Namespaces.collectionURL + "/" + cid;
		return getEntry(url, CollectionEntry.class);
	}

	/**
	 * Get book's tag info
	 * 
	 * @param bookId
	 *            the book Id
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public TagFeed getBookTags(String bookId, int startIndex, int maxResult)
			throws IOException, ServiceException {
		TagQuery query = new TagQuery(new URL(Namespaces.bookSubjectURL + "/"
				+ bookId + "/tags"));

		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, TagFeed.class);
	}

	/**
	 * Get movie's tag info
	 * 
	 * @param bookId
	 *            the book Id
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public TagFeed getMovieTags(String movieId, int startIndex, int maxResult)
			throws IOException, ServiceException {
		TagQuery query = new TagQuery(new URL(Namespaces.movieSubjectURL + "/"
				+ movieId + "/tags"));

		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, TagFeed.class);
	}

	/**
	 * Get music's tag info
	 * 
	 * @param bookId
	 *            the book Id
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public TagFeed getMusicTags(String musicId, int startIndex, int maxResult)
			throws IOException, ServiceException {
		TagQuery query = new TagQuery(new URL(Namespaces.musicSubjectURL + "/"
				+ musicId + "/tags"));

		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);

		return query(query, TagFeed.class);
	}

	/**
	 * Get user's entry info by tag
	 * 
	 * @param userId
	 *            the user Id
	 * @param cat
	 *            the cat info(one of the "movie","music" and "book")
	 * @param startIndex
	 *            the start index of the returned feed
	 * @param maxResult
	 *            the max number of the returned feed
	 */
	public TagFeed getUserTags(String userId, String cat, int startIndex,
			int maxResult) throws IOException, ServiceException {
		TagQuery query = new TagQuery(new URL(Namespaces.userURL + "/" + userId
				+ "/tags"));
		query.setCat(cat);

		query.setStartIndex(startIndex);
		query.setMaxResults(maxResult);
		return query(query, TagFeed.class);
	}

	/**
	 * Create a review entry for an entry
	 * 
	 * @param subjectEntry
	 *            the subject entry to be reviewed
	 * @param title
	 *            the title of the review
	 * @param content
	 *            the content of the review (at least 50 words)
	 * @param rating
	 *            the rating of the subject entry(1-5)
	 */
	public ReviewEntry createReview(SubjectEntry subjectEntry,
			TextConstruct title, TextConstruct content, Rating rating)
			throws IOException, ServiceException {
		String url = Namespaces.reviewCreateURL;
		ReviewEntry re = new ReviewEntry();
		Subject subject = new Subject();

		subject.setId(subjectEntry.getId());
		re.setSubject(subject);
		if (title != null) {
			re.setTitle(title);
		}
		if (content != null) {
			re.setContent(content);
		}
		if (rating != null) {
			re.setRating(rating);
		}

		return insert(new URL(url), re);
	}

	/**
	 * update a review entry for an entry
	 * 
	 * @param reviewEntry
	 *            the review entry to be updated
	 * @param title
	 *            the title of the review
	 * @param content
	 *            the content of the review (at least 50 words)
	 * @param rating
	 *            the rating of the subject entry(1-5)
	 */
	public ReviewEntry updateReview(ReviewEntry reviewEntry,
			TextConstruct title, TextConstruct content, Rating rating)
			throws IOException, ServiceException {
		// String url = Namespaces.reviewURL + "/" + reviewId;
		// ReviewEntry re = getEntry(url, ReviewEntry.class);
		ReviewEntry re = new ReviewEntry(reviewEntry);
		if (title != null) {
			re.setTitle(title);
		}
		if (content != null) {
			re.setContent(content);
		}
		if (rating != null) {
			re.setRating(rating);
		}

		return update(new URL(reviewEntry.getId()), re);
	}

	/**
	 * delete a review entry for an entry
	 * 
	 * @param reviewEntry
	 *            the review entry to be deleted
	 */
	public void deleteReview(ReviewEntry reviewEntry) throws IOException,
			ServiceException {
		delete(new URL(reviewEntry.getId()));
	}

	/**
	 * Create a collection for an entry
	 * 
	 * @param status
	 *            the status of the entry collection (book:wish, reading, read
	 *            movie:wish, watched tv:wish, watching, watched music:wish,
	 *            listening, listened)
	 * @param se
	 *            the subject entry to be collected
	 * @param tags
	 *            the tag list of the collection
	 * @param rating
	 *            the rating of the subject entry(1-5)
	 */
	public CollectionEntry createCollection(Status status, SubjectEntry se,
			List<Tag> tags, Rating rating) throws MalformedURLException,
			IOException, ServiceException {
		String url = Namespaces.collectionCreateURL;
		CollectionEntry ceNew = new CollectionEntry();
		Subject subject = new Subject();
		subject.setId(se.getId());
		ceNew.setSubjectEntry(subject);

		if (status != null) {
			ceNew.setStatus(status);
		}
		if (tags != null) {
			ceNew.setTags(tags);
		}
		if (rating != null) {
			ceNew.setRating(rating);
		}
		/*
		 * Writer w = new OutputStreamWriter(System.out); XmlWriter xw = new
		 * XmlWriter(w); ceNew.generateAtom(xw, extProfile); xw.flush();
		 * System.out.println();
		 */
		return insert(new URL(url), ceNew);

	}

	/**
	 * update a collection for an entry
	 * 
	 * @param status
	 *            the status of the entry collection (book:wish, reading, read
	 *            movie:wish, watched tv:wish, watching, watched music:wish,
	 *            listening, listened)
	 * @param ce
	 *            the entry collection
	 * @param tags
	 *            the tag list of the collection
	 * @param rating
	 *            the rating of the subject entry(1-5)
	 */
	public CollectionEntry updateCollection(CollectionEntry ce, Status status,
			List<Tag> tags, Rating rating) throws MalformedURLException,
			IOException, ServiceException {

		CollectionEntry ceNew = new CollectionEntry();
		ceNew.setId(ce.getId());

		Subject subject = new Subject();
		subject.setId(ce.getSubjectEntry().getId());
		ceNew.setSubjectEntry(subject);

		if (status != null) {
			ceNew.setStatus(status);
		} else {
			ceNew.setStatus(ce.getStatus());
		}
		if (tags != null) {
			ceNew.setTags(tags);
		} else {
			ceNew.setTags(ce.getTags());
		}
		if (rating != null) {
			ceNew.setRating(rating);
		} else {
			ceNew.setRating(ce.getRating());
		}
		/*
		 * Writer w = new OutputStreamWriter(System.out); XmlWriter xw = new
		 * XmlWriter(w); ceNew.generateAtom(xw, extProfile); xw.flush();
		 * System.out.println();
		 */
		return update(new URL(ce.getId()), ceNew);
	}

	/**
	 * delete a collection for an entry
	 * 
	 * @param ce
	 *            the entry collection to be deleted
	 */
	public void deleteCollection(CollectionEntry ce)
			throws MalformedURLException, IOException, ServiceException {
		delete(new URL(ce.getId()));
	}

}

package com.google.gdata.data.douban;

import com.google.gdata.data.ExtensionDescription;


@ExtensionDescription.Default(
		nsAlias = Namespaces.doubanAlias, 
		nsUri = Namespaces.doubanNamespace, 
		localName = "location")
public class Location extends AbstractFreeTextExtension {
	/** Creates an empty tag. */
	public Location() {
	}

	/**
	 * Creates a tag and initializes its content.
	 * 
	 * @param location
	 *            content
	 */
	public Location(String location) {
		super(location);
	}

}
